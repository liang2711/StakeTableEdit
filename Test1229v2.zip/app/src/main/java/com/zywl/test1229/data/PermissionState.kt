package com.zywl.test1229.data

enum class PermissionState {
    None, Granted, Denied
}