package com.zywl.test1229.ktx

val Any.TAG: String get() = this::class.java.simpleName