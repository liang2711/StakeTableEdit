package com.zywl.test1229.di

import com.zywl.test1229.data.PermissionState
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.flow.MutableStateFlow
import javax.inject.Qualifier
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object SharedModule {
    @Provides
    @PermissionStateFlow
    @Singleton
    fun providePermissionState(): MutableStateFlow<PermissionState> {
        return MutableStateFlow(PermissionState.None)
    }
}

@Qualifier
@Retention(AnnotationRetention.BINARY)
annotation class PermissionStateFlow